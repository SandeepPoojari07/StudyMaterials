package com.capgemini.hellodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellodemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellodemoApplication.class, args);
	}
}
