package hello;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface CustomerDao extends CrudRepository<Customer, Long> {

    List<Customer> findByLastName(String lastName);
    
    @Query("select c from Customer c where c.firstName = ?1")
    Customer findByFirstName(String firstname);
}
