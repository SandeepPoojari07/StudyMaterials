package hello;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	
	@Autowired	
	CustomerDao customerdao;
	
	@Autowired
	DataSource ds;
	
	public void addCustomer(Customer cs) {
		customerdao.save(cs);
	}
	
	public Customer getCustomer(Long id) {
		Customer cs1= customerdao.findOne(id);
		//System.out.println(cs1);
		return cs1;
	}
	
	public Customer getCustomer(String firstName) {
		Customer cs1= customerdao.findByFirstName(firstName);
		//System.out.println(cs1);
		return cs1;
	}
	

}
