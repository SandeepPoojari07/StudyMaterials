package hello;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CommandlineStartupRunner implements CommandLineRunner{

	@Autowired
	CustomerService customerservice;
	
	@Override
	public void run(String... arg0) throws Exception {		
		System.out.println(customerservice.ds);		
	    Customer cust1= new Customer("Anil", "Patil");
        customerservice.addCustomer(cust1);			
	  //  Customer cs2= customerservice.getCustomer(1L);
	  //  System.out.println(cs2);
		
		Customer cs3= customerservice.getCustomer("Anil");
		System.out.println(cs3);
		
	}

}

