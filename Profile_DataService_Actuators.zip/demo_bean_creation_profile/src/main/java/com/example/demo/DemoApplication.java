package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;



@SpringBootApplication

public class DemoApplication {

	public static void main(String[] args) {
		ApplicationContext ctx= SpringApplication.run(DemoApplication.class, args);
		
		
		Employee emp2= (Employee) ctx.getBean("emp",Employee.class);
		System.out.println(emp2);
		
		Developer emp3= (Developer) ctx.getBean("developer",Developer.class);
		System.out.println(emp3);
		
		
	}
}
