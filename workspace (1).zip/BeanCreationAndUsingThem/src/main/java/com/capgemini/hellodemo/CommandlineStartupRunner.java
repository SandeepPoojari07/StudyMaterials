package com.capgemini.hellodemo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CommandlineStartupRunner implements CommandLineRunner{

	@Override
	public void run(String... arg0) throws Exception {
		System.out.println("Console- Hello from Spring Boot 2 ");
		
	}

}

