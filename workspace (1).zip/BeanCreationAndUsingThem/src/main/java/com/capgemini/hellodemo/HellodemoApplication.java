package com.capgemini.hellodemo;
//inspecting beans provided by spring boot

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

/*
@SpringBootApplication
public class HellodemoApplication {

	public static void main(String[] args) {
		ApplicationContext ctx= SpringApplication.run(HellodemoApplication.class, args);
		String[] beanNames= ctx.getBeanDefinitionNames();
		Arrays.sort(beanNames);
		for(String beanName: beanNames) {
			System.out.println(beanName);
		}
		
	}
*/
@SpringBootApplication
public class HellodemoApplication {

	/*
	
	@Override
	public void run(String... arg0) throws Exception {
		System.out.println("Console- Hello from Spring Boot ");
		
	}*/
	
	public static void main(String[] args) {
		SpringApplication.run(HellodemoApplication.class, args);
	   
	}
}

