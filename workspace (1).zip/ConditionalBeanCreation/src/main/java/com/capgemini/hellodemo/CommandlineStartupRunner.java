package com.capgemini.hellodemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CommandlineStartupRunner implements CommandLineRunner{

	@Autowired 
	ReadProperties prop;
	
	@Override
	public void run(String... arg0) throws Exception {
		System.out.println("Console- Hello from Spring Boot 2 ");
		prop.showName();
		
	}

}

