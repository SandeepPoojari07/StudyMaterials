package com.capgemini.hellodemo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:global.properties")
public class ReadProperties {

	@Value("${name}")
	private String myname;
	
	@Value("${email}")
	private String myemail;
	
	public void showName(){
		System.out.println( " My name : " + myname + "  Email :" +myemail);
	}
	
	
}
