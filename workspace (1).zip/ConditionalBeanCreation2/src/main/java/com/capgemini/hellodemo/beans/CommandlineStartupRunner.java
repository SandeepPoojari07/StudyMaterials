package com.capgemini.hellodemo.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CommandlineStartupRunner implements CommandLineRunner{
	
	//@Autowired
	//Dept department;
	
	@Autowired
	Employee emp;
	
	@Override
	public void run(String... arg0) throws Exception {
		//department.showdepartment();
		emp.sayHi();
		
	}

}

