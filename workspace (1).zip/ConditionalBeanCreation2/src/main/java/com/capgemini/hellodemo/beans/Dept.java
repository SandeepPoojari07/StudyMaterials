package com.capgemini.hellodemo.beans;

public class Dept {
	String deptname;
	Dept(String name) {
		deptname=name;
	}
	public void showdepartment() {
		System.out.println(deptname);
	}

}
