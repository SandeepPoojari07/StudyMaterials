package com.capgemini.hellodemo.beans;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/*
 * Beans can be conditionaly created based on 
 * ConditionalOnBean, ConditionalOnClass,ConditonalOnJava,ConditonalOnJNDI,
 * ConditionalOnMissingBean, ConditionalOnMissingClass, ConditionalOnProperty,
 * ConditionalOnResource,ConditoanlOnWebApplication etc
 */
@Configuration
public class ConditionalOnBeanConfig {

	/*
	@Bean
	public Employee getEmployee()
	{
		return new Employee("Anil");
	}	
*/

	@Bean
	@ConditionalOnBean(name="getEmployee" )
	public Dept myDept()
	{
		return new Dept("L&D");
	}	

	@Bean
	@ConditionalOnMissingBean(name="abc")
	public Employee getEmp()
	{
			return new Employee("Sunil");
	}
	


	
}


