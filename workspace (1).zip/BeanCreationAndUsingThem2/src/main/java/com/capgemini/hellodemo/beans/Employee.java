package com.capgemini.hellodemo.beans;
public class Employee {
	private String name; 
	Employee (String name){
		this.name=name;
	}
	
	public void sayHi() {
		System.out.println("Hi "+ name);
	}
}