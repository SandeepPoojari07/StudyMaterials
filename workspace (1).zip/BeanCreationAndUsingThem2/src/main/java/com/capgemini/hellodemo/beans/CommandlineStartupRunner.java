package com.capgemini.hellodemo.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class CommandlineStartupRunner implements CommandLineRunner{

	
	@Qualifier("getEmployee")
	@Autowired
	Employee emp;
	
	@Override
	public void run(String... arg0) throws Exception {
		emp.sayHi();
		
	}

}

