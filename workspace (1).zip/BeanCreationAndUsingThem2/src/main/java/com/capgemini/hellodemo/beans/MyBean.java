package com.capgemini.hellodemo.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class MyBean {
	
	@Bean
	public Employee getEmployee()
	{
		return new Employee("Anil");
	}
	
	@Bean
	public Employee getEmployee2()
	{
		return new Employee("Sunil");
	}
	
	
}


